<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex,nofollow">
    <title><?php echo $__env->yieldContent('title', 'Mail panel'); ?> · <?php echo e(config('app.name')); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
</head>
<body>
<?php if(auth()->guard()->check()): ?>
    <?php ($u = auth()->user()); ?>
    <header class="top">
        <span class="brand"><?php echo e(config('app.name')); ?></span>
        <nav>
            <a href="<?php echo e(route('dashboard')); ?>" class="<?php echo e(request()->routeIs('dashboard') ? 'on' : ''); ?>">Dashboard</a>
            <a href="<?php echo e(route('mailboxes.index')); ?>" class="<?php echo e(request()->routeIs('mailboxes.*') ? 'on' : ''); ?>">Mailboxes</a>
            <a href="<?php echo e(route('forwarders.index')); ?>" class="<?php echo e(request()->routeIs('forwarders.*') ? 'on' : ''); ?>">Forwarders</a>
            <a href="<?php echo e(route('catchall.index')); ?>" class="<?php echo e(request()->routeIs('catchall.*') ? 'on' : ''); ?>">Catch-all</a>
            <?php if($u->role !== 'read_only'): ?><a href="<?php echo e(route('bulk.index')); ?>" class="<?php echo e(request()->routeIs('bulk.*') ? 'on' : ''); ?>">Bulk import</a><?php endif; ?>
            <a href="<?php echo e(route('health.index')); ?>" class="<?php echo e(request()->routeIs('health.*') ? 'on' : ''); ?>">Domain health</a>
            <a href="<?php echo e(route('trace.index')); ?>" class="<?php echo e(request()->routeIs('trace.*') ? 'on' : ''); ?>">Delivery trace</a>
            <a href="<?php echo e(route('audit.index')); ?>" class="<?php echo e(request()->routeIs('audit.*') ? 'on' : ''); ?>">Audit log</a>
            <?php if($u->isSuperAdmin()): ?>
                <a href="<?php echo e(route('admin.users.index')); ?>" class="<?php echo e(request()->routeIs('admin.users.*') ? 'on' : ''); ?>">Users</a>
                <a href="<?php echo e(route('admin.domains.index')); ?>" class="<?php echo e(request()->routeIs('admin.domains.*') ? 'on' : ''); ?>">Domains</a>
                <a href="<?php echo e(route('admin.settings')); ?>" class="<?php echo e(request()->routeIs('admin.settings*') ? 'on' : ''); ?>">Settings</a>
            <?php endif; ?>
        </nav>
        <div class="who">
            <span><?php echo e($u->email); ?> · <?php echo e($u->roleLabel()); ?></span>
            <form method="post" action="<?php echo e(route('logout')); ?>"><?php echo csrf_field(); ?><button type="submit">Sign out</button></form>
        </div>
    </header>
<?php endif; ?>
<main>
    <?php if(session('status')): ?><div class="flash ok"><?php echo e(session('status')); ?></div><?php endif; ?>
    <?php if($errors->any()): ?>
        <div class="flash err"><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><div><?php echo e($e); ?></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div>
    <?php endif; ?>
    <?php echo $__env->yieldContent('content'); ?>
</main>
</body>
</html>
<?php /**PATH D:\Xamp\htdocs\Cpanel-Email_system\mailpanel\resources\views/layouts/app.blade.php ENDPATH**/ ?>