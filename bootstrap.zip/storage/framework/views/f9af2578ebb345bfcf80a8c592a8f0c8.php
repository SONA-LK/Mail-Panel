<div class="card">
    <strong>Mail client settings</strong>
    <table>
        <tr><th>Username</th><td><?php echo e($settings['address']); ?></td></tr>
        <tr><th>Incoming IMAP</th><td><?php echo e($settings['imap_host']); ?> · port <?php echo e($settings['imap_port']); ?> · SSL/TLS</td></tr>
        <tr><th>Incoming POP3</th><td><?php echo e($settings['imap_host']); ?> · port <?php echo e($settings['pop_port']); ?> · SSL/TLS</td></tr>
        <tr><th>Outgoing SMTP</th><td><?php echo e($settings['smtp_host']); ?> · port <?php echo e($settings['smtp_port']); ?> · SSL/TLS (or <?php echo e($settings['smtp_starttls_port']); ?> STARTTLS)</td></tr>
        <tr><th>Webmail</th><td><a href="<?php echo e($settings['webmail']); ?>" rel="noopener noreferrer" target="_blank"><?php echo e($settings['webmail']); ?></a></td></tr>
    </table>
</div>
<?php /**PATH D:\Xamp\htdocs\Cpanel-Email_system\mailpanel\resources\views/mailboxes/partials/settings.blade.php ENDPATH**/ ?>