<?php $__env->startSection('title', 'Forwarders'); ?>
<?php $__env->startSection('content'); ?>
<h1>Forwarders</h1>
<form method="get" class="filters">
    <div><label>Search</label><input type="text" name="q" value="<?php echo e(request('q')); ?>"></div>
    <div><label>Domain</label>
        <select name="domain_id"><option value="">All</option>
            <?php $__currentLoopData = $domains; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($d->id); ?>" <?php if(request('domain_id') == $d->id): echo 'selected'; endif; ?>><?php echo e($d->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
    <div><label>Type</label>
        <select name="type"><option value="">All</option>
            <?php $__currentLoopData = ['address' => 'Address', 'domain' => 'Domain', 'catchall' => 'Catch-all']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($k); ?>" <?php if(request('type') === $k): echo 'selected'; endif; ?>><?php echo e($v); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
    <button type="submit">Filter</button>
    <a class="btn sec" href="<?php echo e(route('forwarders.export', request()->query())); ?>">Export CSV</a>
    <?php if(auth()->user()->role !== 'read_only'): ?><a class="btn" href="<?php echo e(route('forwarders.create')); ?>">New forwarder</a><?php endif; ?>
</form>

<form method="get" class="filters card">
    <div><label>Reverse lookup: which forwarders point to this address?</label>
        <input type="email" name="points_to" value="<?php echo e(request('points_to')); ?>" placeholder="anna@example.com"></div>
    <button class="sec" type="submit">Look up</button>
</form>
<?php if($reverse !== null): ?>
    <div class="card"><strong>Pointing to <?php echo e(request('points_to')); ?>:</strong>
        <?php $__empty_1 = true; $__currentLoopData = $reverse; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><div><?php echo e($f->source); ?> <span class="muted small">(<?php echo e($f->type); ?>)</span></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><div class="muted">Nothing forwards to this address.</div><?php endif; ?></div>
<?php endif; ?>

<table>
    <tr><th>Source</th><th>Destination</th><th>Type</th><th>Domain</th><th></th></tr>
    <?php $__empty_1 = true; $__currentLoopData = $forwarders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($f->source); ?></td><td><?php echo e($f->destination); ?></td>
            <td><span class="badge"><?php echo e($f->type); ?></span></td><td><?php echo e($f->domain->name); ?></td>
            <td class="right">
                <?php if(auth()->user()->canManage($f->domain) && $f->type === 'address'): ?>
                    <form method="post" class="inline" action="<?php echo e(route('forwarders.destroy', $f)); ?>"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button class="sm danger" type="submit">Remove</button></form>
                <?php elseif(auth()->user()->canManage($f->domain) && $f->type === 'domain'): ?>
                    <form method="post" class="inline" action="<?php echo e(route('forwarders.domain.destroy', $f)); ?>"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button class="sm danger" type="submit">Remove</button></form>
                <?php endif; ?>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="5" class="muted">No forwarders.</td></tr><?php endif; ?>
</table>
<div class="pager"><?php echo e($forwarders->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Xamp\htdocs\Cpanel-Email_system\mailpanel\resources\views/forwarders/index.blade.php ENDPATH**/ ?>