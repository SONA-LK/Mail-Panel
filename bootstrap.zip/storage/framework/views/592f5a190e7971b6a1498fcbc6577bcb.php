<?php $__env->startSection('title', $mailbox->address); ?>
<?php $__env->startSection('content'); ?>
<h1><?php echo e($mailbox->address); ?> <span class="badge <?php echo e($mailbox->isSuspended() ? 'warn' : 'ok'); ?>"><?php echo e($mailbox->statusLabel()); ?></span></h1>
<p>
    <a href="<?php echo e($webmail); ?>" target="_blank" rel="noopener noreferrer" class="btn sec sm">Open webmail</a>
    <a href="<?php echo e(route('mailboxes.settings', $mailbox)); ?>" class="btn sec sm">Client settings</a>
    <a href="<?php echo e(route('audit.index', ['q' => $mailbox->address])); ?>" class="btn sec sm">Activity</a>
</p>

<div class="grid">
    <div class="card">
        <strong>Quota</strong>
        <p><?php echo e($mailbox->used_mb); ?> MB used of <?php echo e($mailbox->quota_mb ? $mailbox->quota_mb.' MB' : 'unlimited'); ?>

            <?php if($mailbox->usagePercent() !== null): ?> (<?php echo e($mailbox->usagePercent()); ?>%)<?php endif; ?></p>
        <?php if($canManage): ?>
        <form method="post" action="<?php echo e(route('mailboxes.quota', $mailbox)); ?>"><?php echo csrf_field(); ?>
            <input type="number" name="quota_mb" min="1" max="<?php echo e(config('cpanel.max_quota_mb')); ?>" value="<?php echo e($mailbox->quota_mb); ?>" required style="width:140px">
            <button class="sm" type="submit">Change quota</button>
        </form>
        <?php endif; ?>
    </div>

    <?php if($canManage): ?>
    <div class="card">
        <strong>Password</strong>
        <form method="post" action="<?php echo e(route('mailboxes.password', $mailbox)); ?>"><?php echo csrf_field(); ?>
            <input type="text" name="password" placeholder="leave empty to generate" autocomplete="off" minlength="8">
            <p><button class="sm" type="submit">Reset password</button></p>
        </form>
    </div>

    <div class="card">
        <strong>Suspend or delete</strong>
        <?php if($pending): ?><p class="small">Suspended <?php echo e($pending->suspended_at->diffForHumans()); ?>. Deletion allowed from <strong><?php echo e($pending->delete_after->format('Y-m-d')); ?></strong>.</p><?php endif; ?>
        <?php if($mailbox->isSuspended()): ?>
            <form method="post" action="<?php echo e(route('mailboxes.unsuspend', $mailbox)); ?>" class="inline"><?php echo csrf_field(); ?><button class="sm sec" type="submit">Re-enable</button></form>
        <?php else: ?>
            <form method="post" action="<?php echo e(route('mailboxes.suspend', $mailbox)); ?>" class="inline"><?php echo csrf_field(); ?><button class="sm sec" type="submit">Suspend (keeps mail)</button></form>
        <?php endif; ?>
        <a class="btn danger sm" href="<?php echo e(route('mailboxes.confirm-delete', $mailbox)); ?>">Delete…</a>
        <?php if($deleteBlocked): ?><p class="small muted"><?php echo e($deleteBlocked); ?></p><?php endif; ?>
    </div>
    <?php endif; ?>
</div>

<h2>Forwarders from this address</h2>
<table>
    <tr><th>Destination</th><th></th></tr>
    <?php $__empty_1 = true; $__currentLoopData = $forwardersFrom; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr><td><?php echo e($f->destination); ?></td><td class="right">
            <?php if($canManage && $f->type === 'address'): ?><form method="post" class="inline" action="<?php echo e(route('forwarders.destroy', $f)); ?>"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button class="sm danger" type="submit">Remove</button></form><?php endif; ?></td></tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="2" class="muted">None.</td></tr><?php endif; ?>
</table>
<?php if($canManage): ?><p><a href="<?php echo e(route('forwarders.create')); ?>">Add a forwarder</a></p><?php endif; ?>

<h2>Forwarders that point here</h2>
<table>
    <tr><th>Source</th><th>Type</th></tr>
    <?php $__empty_1 = true; $__currentLoopData = $forwardersTo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><tr><td><?php echo e($f->source); ?></td><td><?php echo e($f->type); ?></td></tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="2" class="muted">None.</td></tr><?php endif; ?>
</table>

<h2>Autoresponder</h2>
<div class="card">
<?php if($autoresponder): ?>
    <p>Active: <strong><?php echo e($autoresponder->subject); ?></strong>
        <?php if($autoresponder->start_at): ?> from <?php echo e($autoresponder->start_at->format('Y-m-d')); ?><?php endif; ?>
        <?php if($autoresponder->stop_at): ?> until <?php echo e($autoresponder->stop_at->format('Y-m-d')); ?><?php endif; ?></p>
    <?php if($canManage): ?><form method="post" action="<?php echo e(route('mailboxes.autoresponder.destroy', $mailbox)); ?>"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button class="sm danger" type="submit">Remove autoresponder</button></form><?php endif; ?>
<?php elseif($canManage): ?>
    <form method="post" action="<?php echo e(route('mailboxes.autoresponder', $mailbox)); ?>"><?php echo csrf_field(); ?>
        <label>Subject</label><input type="text" name="subject" required maxlength="200">
        <label>Message</label><textarea name="body" required maxlength="5000"></textarea>
        <label>Start date</label><input type="date" name="start">
        <label>Stop date</label><input type="date" name="stop">
        <p><button class="sm" type="submit">Save autoresponder</button></p>
    </form>
<?php else: ?><span class="muted">None.</span><?php endif; ?>
</div>

<h2>Filters</h2>
<table>
    <tr><th>Name</th><th>Rule</th><th></th></tr>
    <?php $__empty_1 = true; $__currentLoopData = $filters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr><td><?php echo e($f->name); ?></td><td class="small"><?php echo e($f->rule_summary); ?></td><td class="right">
            <?php if($canManage): ?><form method="post" class="inline" action="<?php echo e(route('mailboxes.filters.destroy', [$mailbox, $f])); ?>"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button class="sm danger" type="submit">Remove</button></form><?php endif; ?></td></tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="3" class="muted">None.</td></tr><?php endif; ?>
</table>
<?php if($canManage): ?>
<div class="card">
    <strong>Add a filter</strong>
    <form method="post" action="<?php echo e(route('mailboxes.filters.store', $mailbox)); ?>"><?php echo csrf_field(); ?>
        <label>Name</label><input type="text" name="name" required maxlength="80">
        <label>If</label>
        <select name="field" style="width:auto"><option value="from">From</option><option value="to">To</option><option value="subject">Subject</option></select>
        <select name="match" style="width:auto"><option value="contains">contains</option><option value="equals">equals</option><option value="begins">begins with</option><option value="ends">ends with</option></select>
        <input type="text" name="value" required maxlength="200">
        <label>Then</label>
        <select name="action" style="width:auto"><option value="discard">Discard</option><option value="redirect">Redirect to address</option><option value="move">Move to folder</option></select>
        <input type="text" name="destination" placeholder="address or folder name (not needed for discard)" maxlength="200">
        <p><button class="sm" type="submit">Save filter</button></p>
    </form>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Xamp\htdocs\Cpanel-Email_system\mailpanel\resources\views/mailboxes/show.blade.php ENDPATH**/ ?>