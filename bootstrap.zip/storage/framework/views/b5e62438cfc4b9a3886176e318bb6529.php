<?php $__env->startSection('title', 'Mailboxes'); ?>
<?php $__env->startSection('content'); ?>
<h1>Mailboxes</h1>
<form method="get" class="filters">
    <div><label>Search</label><input type="text" name="q" value="<?php echo e(request('q')); ?>" placeholder="address"></div>
    <div><label>Domain</label>
        <select name="domain_id"><option value="">All</option>
            <?php $__currentLoopData = $domains; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($d->id); ?>" <?php if(request('domain_id') == $d->id): echo 'selected'; endif; ?>><?php echo e($d->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select></div>
    <div><label>Status</label>
        <select name="status"><option value="">Any</option>
            <option value="active" <?php if(request('status') === 'active'): echo 'selected'; endif; ?>>Active</option>
            <option value="suspended" <?php if(request('status') === 'suspended'): echo 'selected'; endif; ?>>Suspended</option></select></div>
    <div><label>Quota</label>
        <select name="quota"><option value="">Any</option><option value="near" <?php if(request('quota') === 'near'): echo 'selected'; endif; ?>>Near limit (<?php echo e($warnPct); ?>%+)</option></select></div>
    <div><label>Forwarders</label>
        <select name="forwarders"><option value="">Any</option><option value="with" <?php if(request('forwarders') === 'with'): echo 'selected'; endif; ?>>Has forwarders</option></select></div>
    <button type="submit">Filter</button>
    <a class="btn sec" href="<?php echo e(route('mailboxes.export', request()->query())); ?>">Export CSV</a>
    <?php if(auth()->user()->role !== 'read_only'): ?><a class="btn" href="<?php echo e(route('mailboxes.create')); ?>">New mailbox</a><?php endif; ?>
</form>

<table>
    <tr><th>Address</th><th>Quota</th><th>Status</th><th>Forwarders</th><th>Synced</th></tr>
    <?php $__empty_1 = true; $__currentLoopData = $mailboxes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <?php ($pct = $m->usagePercent()); ?>
        <tr>
            <td><a href="<?php echo e(route('mailboxes.show', $m)); ?>"><?php echo e($m->address); ?></a></td>
            <td>
                <?php if($pct === null): ?><span class="muted"><?php echo e($m->used_mb); ?> MB / unlimited</span>
                <?php else: ?><span class="bar <?php echo e($pct >= 95 ? 'bad' : ($pct >= $warnPct ? 'warn' : '')); ?>"><i style="width:<?php echo e(min(100, $pct)); ?>%"></i></span>
                    <span class="small"><?php echo e($m->used_mb); ?> / <?php echo e($m->quota_mb); ?> MB (<?php echo e($pct); ?>%)</span><?php endif; ?>
            </td>
            <td><span class="badge <?php echo e($m->isSuspended() ? 'warn' : 'ok'); ?>"><?php echo e($m->statusLabel()); ?></span></td>
            <td><?php echo e($m->forwarder_count); ?></td>
            <td class="muted small"><?php echo e($m->last_synced_at?->diffForHumans() ?? 'never'); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr><td colspan="5" class="muted">No mailboxes match. If this is a new install, run a sync from Settings.</td></tr>
    <?php endif; ?>
</table>
<div class="pager"><?php echo e($mailboxes->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Xamp\htdocs\Cpanel-Email_system\mailpanel\resources\views/mailboxes/index.blade.php ENDPATH**/ ?>