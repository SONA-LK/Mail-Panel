<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex,nofollow">
    <title><?php echo $__env->yieldContent('title', 'Install'); ?> · Mail Panel</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
</head>
<body>
<main class="wizard">
    <h1>Mail Panel setup</h1>
    <?php if(isset($step)): ?>
        <ol class="steps">
            <?php $__currentLoopData = [1 => 'Server check', 2 => 'Database', 3 => 'cPanel', 4 => 'Google and admin', 5 => 'Install']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="<?php echo e($n === $step ? 'on' : ($n < $step ? 'done' : '')); ?>"><?php echo e($n); ?>. <?php echo e($label); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ol>
    <?php endif; ?>
    <?php if(session('status')): ?><div class="flash ok"><?php echo e(session('status')); ?></div><?php endif; ?>
    <?php if($errors->any()): ?>
        <div class="flash err"><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><div><?php echo e($e); ?></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div>
    <?php endif; ?>
    <?php echo $__env->yieldContent('content'); ?>
</main>
</body>
</html>
<?php /**PATH D:\Xamp\htdocs\Cpanel-Email_system\mailpanel\resources\views/install/layout.blade.php ENDPATH**/ ?>