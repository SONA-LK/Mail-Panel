<?php $__env->startSection('title', 'Installed'); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
    <h2>The panel is installed</h2>
    <?php $__currentLoopData = $r['warnings']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><div class="flash warn"><?php echo e($w); ?></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <p><strong><?php echo e($r['admin']); ?></strong> is the first super admin. <?php echo e($r['imported']); ?> domain(s) were added.</p>

    <h3>Two things left to do</h3>
    <ol>
        <li>
            <strong>Add the cron job</strong> (cPanel, Cron Jobs, once per minute). It runs the background queue, the nightly sync, health checks and the first sync of your domains:
            <pre><?php echo e($r['cron']); ?></pre>
            <span class="hint">If <code>php</code> is not found, use the full path your host shows under Cron Jobs, for example <code>/usr/local/bin/php</code>.</span>
        </li>
        <li>
            <strong>Check the Google redirect URI</strong> is registered exactly as <code><?php echo e($redirectUri); ?></code>, then sign in:
            <p><a class="btn" href="<?php echo e($r['login_url']); ?>">Sign in with Google</a></p>
        </li>
    </ol>
    <p class="muted small">The setup wizard is now switched off. To run it again, delete <code>storage/app/installed.lock</code> and <code>.env</code>. Welcome emails to new mailboxes stay off until you set the <code>MAIL_*</code> values in <code>.env</code>.</p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('install.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Xamp\htdocs\Cpanel-Email_system\mailpanel\resources\views/install/done.blade.php ENDPATH**/ ?>