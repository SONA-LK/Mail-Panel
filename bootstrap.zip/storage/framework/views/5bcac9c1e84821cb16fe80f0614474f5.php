<?php $__env->startSection('title', isset($reset) ? 'Password reset' : 'Mailbox created'); ?>
<?php $__env->startSection('content'); ?>
<h1><?php echo e(isset($reset) ? 'Password reset' : 'Mailbox created'); ?>: <?php echo e($mailbox->address); ?></h1>
<div class="card">
    <p><strong>Password (shown once, never stored):</strong></p>
    <div class="secret"><?php echo e($password); ?></div>
    <p class="muted small">Copy it now. Reloading this page will not show it again. Do not reload or resubmit the form.</p>
    <?php if($mailSent): ?><p class="flash ok">Client settings were emailed (without the password).</p><?php endif; ?>
</div>
<?php if($settings): ?>
    <?php echo $__env->make('mailboxes.partials.settings', ['settings' => $settings], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php endif; ?>
<p><a class="btn" href="<?php echo e(route('mailboxes.show', $mailbox)); ?>">Open mailbox</a></p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Xamp\htdocs\Cpanel-Email_system\mailpanel\resources\views/mailboxes/created.blade.php ENDPATH**/ ?>