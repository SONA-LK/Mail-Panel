<?php $__env->startSection('title', 'Domains'); ?>
<?php $__env->startSection('content'); ?>
<h1>Domains</h1>
<p><a class="btn" href="<?php echo e(route('admin.domains.import')); ?>">Import from cPanel</a> <a class="btn sec" href="<?php echo e(route('admin.domains.create')); ?>">Add domain manually</a></p>
<table>
    <tr><th>Domain</th><th>Purpose</th><th>Quota</th><th>Naming</th><th>Catch-all</th><th>Forwarding</th><th>Mailboxes</th><th>Forwarders</th><th></th></tr>
    <?php $__currentLoopData = $domains; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($d->name); ?></td><td><?php echo e($d->purpose); ?></td><td><?php echo e($d->default_quota_mb); ?> MB</td><td><?php echo e($d->naming_pattern); ?></td>
            <td><?php echo e($d->catchall_policy); ?></td><td><?php echo e($d->forwarding_policy); ?></td><td><?php echo e($d->mailboxes_count); ?></td><td><?php echo e($d->forwarders_count); ?></td>
            <td class="right"><a class="btn sm sec" href="<?php echo e(route('admin.domains.edit', $d)); ?>">Edit</a></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Xamp\htdocs\Cpanel-Email_system\mailpanel\resources\views/admin/domains/index.blade.php ENDPATH**/ ?>