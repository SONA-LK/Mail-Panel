<?php $__env->startSection('title', 'Unlock setup'); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
    <h2>Welcome</h2>
    <p>This wizard connects the panel to your cPanel account, creates its database and your first admin. It takes about five minutes.</p>
    <?php if($codeMissing): ?>
        <div class="flash err">The setup code could not be created. Make the folder <code>storage/app</code> writable (chmod 755 or 775), reload this page, then read the code from <code><?php echo e($codeFile); ?></code>.</div>
    <?php else: ?>
        <p>To make sure only you can run the setup, open the file <code><?php echo e($codeFile); ?></code> in the panel folder on the server (cPanel File Manager or SSH) and type the code it contains.</p>
        <form method="post" action="<?php echo e(route('install.unlock')); ?>">
            <?php echo csrf_field(); ?>
            <label for="code">Setup code</label>
            <input type="text" id="code" name="code" autocomplete="off" autofocus placeholder="XXXX-XXXX-XXXX">
            <p><button type="submit">Continue</button></p>
        </form>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('install.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Xamp\htdocs\Cpanel-Email_system\mailpanel\resources\views/install/unlock.blade.php ENDPATH**/ ?>