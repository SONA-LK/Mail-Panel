<?php $__env->startSection('title', 'Domain health'); ?>
<?php $__env->startSection('content'); ?>
<h1>Domain health</h1>
<p class="muted">SPF, DKIM, DMARC and MX read from public DNS. Fix red items in cPanel, Email Deliverability.</p>

<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php ($d = $i['domain']); ?>
    <?php ($r = $i['result']); ?>
    <div class="card">
        <strong><?php echo e($d->name); ?></strong>
        <?php if($r): ?><span class="badge <?php echo e($r['worst']); ?>"><?php echo e($r['worst']); ?></span> <span class="muted small">checked <?php echo e($r['checked_at']); ?></span><?php endif; ?>
        <form method="post" class="inline" action="<?php echo e(route('health.run', $d)); ?>"><?php echo csrf_field(); ?> <button class="sm sec" type="submit">Check now</button></form>
        <?php if($r): ?>
            <table>
                <tr><th>Check</th><th>Status</th><th>Detail</th><th>What to do</th></tr>
                <?php $__currentLoopData = $r['checks']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr><td><?php echo e($c['name']); ?></td><td><span class="badge <?php echo e($c['status']); ?>"><?php echo e($c['status']); ?></span></td>
                        <td class="small" style="word-break:break-all"><?php echo e($c['detail']); ?></td><td class="small"><?php echo e($c['hint']); ?></td></tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        <?php else: ?><p class="muted">Not checked yet.</p><?php endif; ?>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Xamp\htdocs\Cpanel-Email_system\mailpanel\resources\views/health/index.blade.php ENDPATH**/ ?>