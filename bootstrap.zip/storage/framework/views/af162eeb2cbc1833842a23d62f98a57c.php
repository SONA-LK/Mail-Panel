<?php $__env->startSection('title', 'Import #'.$batch->id); ?>
<?php $__env->startSection('content'); ?>
<h1>Import #<?php echo e($batch->id); ?> <span class="badge"><?php echo e($batch->status); ?></span></h1>
<p class="muted"><?php echo e($batch->original_name); ?> · <?php echo e($batch->total_rows); ?> rows</p>

<div class="grid">
    <?php $__currentLoopData = ['valid' => 'ok', 'invalid' => 'bad', 'queued' => '', 'done' => 'ok', 'failed' => 'bad']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s => $cls): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(($counts[$s] ?? 0) > 0): ?><div class="card"><span class="badge <?php echo e($cls); ?>"><?php echo e($s); ?></span> <span class="stat"><?php echo e($counts[$s]); ?></span></div><?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php if($batch->status === 'validated'): ?>
    <div class="card">
        <strong>Dry-run finished. Nothing has been changed in cPanel yet.</strong>
        <form method="post" action="<?php echo e(route('bulk.confirm', $batch)); ?>">
            <?php echo csrf_field(); ?>
            <?php if($hasWarnings): ?>
                <label class="check"><input type="checkbox" name="confirm_external" value="1"> Some rows forward to external addresses (marked below). I understand the risk and want to continue.</label>
            <?php endif; ?>
            <p><button type="submit" <?php if(($counts['valid'] ?? 0) === 0): echo 'disabled'; endif; ?>>Confirm and queue <?php echo e($counts['valid'] ?? 0); ?> valid row(s)</button>
            </p>
        </form>
        <form method="post" action="<?php echo e(route('bulk.cancel', $batch)); ?>"><?php echo csrf_field(); ?><button class="sec" type="submit">Cancel import</button></form>
        <p class="muted small">Invalid rows are skipped and stay in the report.</p>
    </div>
<?php elseif($batch->status === 'queued'): ?>
    <div class="flash warn">Processing in the background (about <?php echo e(config('cpanel.bulk_per_run')); ?> rows per minute). You can close this page; reload to see progress. <?php echo e($batch->done_rows); ?> done, <?php echo e($batch->failed_rows); ?> failed.</div>
<?php endif; ?>

<?php if(in_array($batch->status, ['queued', 'done', 'partial'])): ?>
    <p><a class="btn" href="<?php echo e(route('bulk.result', $batch)); ?>">Download result CSV</a>
        <?php if($secrets): ?><span class="muted small">Generated passwords are included once and wiped after this download.</span><?php endif; ?></p>
<?php endif; ?>

<table>
    <tr><th>Row</th><th>Type</th><th>Address</th><th>Status</th><th>Message</th></tr>
    <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php ($p = $r->payload ?? []); ?>
        <tr>
            <td><?php echo e($r->row_number); ?></td><td><?php echo e($p['type'] ?? ''); ?></td><td><?php echo e($p['address'] ?? ''); ?></td>
            <td><span class="badge <?php echo e(in_array($r->status, ['valid', 'done']) ? 'ok' : (in_array($r->status, ['invalid', 'failed']) ? 'bad' : '')); ?>"><?php echo e($r->status); ?></span></td>
            <td class="small"><?php echo e($r->error_message); ?> <?php if($r->warnings): ?><span class="badge warn"><?php echo e($r->warnings); ?></span><?php endif; ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<div class="pager"><?php echo e($rows->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Xamp\htdocs\Cpanel-Email_system\mailpanel\resources\views/bulk/show.blade.php ENDPATH**/ ?>