<?php $__env->startSection('title', 'Delete mailbox'); ?>
<?php $__env->startSection('content'); ?>
<h1>Delete <?php echo e($mailbox->address); ?></h1>
<div class="flash err">Deleting removes the mailbox <strong>and all of its mail</strong>. This cannot be undone. Consider suspending it first.</div>

<?php if($dangling->isNotEmpty()): ?>
    <div class="flash warn">These forwarders point at this address and will stop working. Remove or redirect them afterwards:
        <ul><?php $__currentLoopData = $dangling; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($f->source); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul></div>
<?php endif; ?>

<?php if($blocked): ?>
    <div class="flash warn"><?php echo e($blocked); ?></div>
    <a class="btn sec" href="<?php echo e(route('mailboxes.show', $mailbox)); ?>">Back</a>
<?php else: ?>
    <form method="post" action="<?php echo e(route('mailboxes.destroy', $mailbox)); ?>" class="card">
        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
        <label>Type <code><?php echo e($mailbox->address); ?></code> to confirm</label>
        <input type="text" name="confirm" autocomplete="off" required>
        <p><button class="danger" type="submit">Delete permanently</button>
            <a class="btn sec" href="<?php echo e(route('mailboxes.show', $mailbox)); ?>">Cancel</a></p>
    </form>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Xamp\htdocs\Cpanel-Email_system\mailpanel\resources\views/mailboxes/delete.blade.php ENDPATH**/ ?>