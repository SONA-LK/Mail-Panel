<?php $__env->startSection('title', 'Users'); ?>
<?php $__env->startSection('content'); ?>
<h1>Panel users</h1>
<p class="muted">Everyone signs in with Google. Add a person's Google email here first; any other account is refused and logged.</p>
<p><a class="btn" href="<?php echo e(route('admin.users.create')); ?>">Add user</a></p>
<table>
    <tr><th>Name</th><th>Google email</th><th>Role</th><th>Domains</th><th>Active</th><th>Last login</th><th></th></tr>
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($u->name); ?></td><td><?php echo e($u->email); ?></td><td><?php echo e($u->roleLabel()); ?></td>
            <td class="small"><?php echo e($u->isSuperAdmin() ? 'All' : $u->domains->pluck('name')->implode(', ')); ?></td>
            <td><span class="badge <?php echo e($u->active ? 'ok' : 'bad'); ?>"><?php echo e($u->active ? 'yes' : 'no'); ?></span></td>
            <td class="small muted"><?php echo e($u->last_login_at?->diffForHumans() ?? 'never'); ?></td>
            <td class="right"><a class="btn sm sec" href="<?php echo e(route('admin.users.edit', $u)); ?>">Edit</a>
                <?php if($u->id !== auth()->id()): ?><form method="post" class="inline" action="<?php echo e(route('admin.users.destroy', $u)); ?>"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button class="sm danger" type="submit">Remove</button></form><?php endif; ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Xamp\htdocs\Cpanel-Email_system\mailpanel\resources\views/admin/users/index.blade.php ENDPATH**/ ?>