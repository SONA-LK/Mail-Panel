<?php $__env->startSection('title', 'Server check'); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
    <h2>Server check</h2>
    <table>
        <?php $__currentLoopData = $req['checks']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($c['label']); ?></td>
                <td><span class="badge <?php echo e($c['ok'] ? 'ok' : ($c['required'] ? 'bad' : 'warn')); ?>"><?php echo e($c['ok'] ? 'OK' : ($c['required'] ? 'Fix' : 'Advice')); ?></span></td>
                <td class="muted small"><?php echo e($c['hint']); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <?php if($req['ok']): ?>
        <p><a class="btn" href="<?php echo e(route('install.database')); ?>">Continue</a></p>
    <?php else: ?>
        <p class="flash err">Fix the items marked "Fix", then <a href="<?php echo e(route('install.start')); ?>">check again</a>.</p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('install.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Xamp\htdocs\Cpanel-Email_system\mailpanel\resources\views/install/requirements.blade.php ENDPATH**/ ?>