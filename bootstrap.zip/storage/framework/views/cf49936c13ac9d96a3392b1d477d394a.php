<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>
<h1>Dashboard</h1>

<?php if($failedJobs > 0): ?><div class="flash err"><?php echo e($failedJobs); ?> background job(s) failed. Check the bulk import reports and the failed_jobs table.</div><?php endif; ?>
<?php $__currentLoopData = $syncErrors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $run): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="flash warn">Sync problem on <?php echo e($run->domain?->name); ?> (<?php echo e($run->started_at->diffForHumans()); ?>): <?php echo e(\Illuminate\Support\Str::limit($run->errors, 200)); ?></div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__currentLoopData = $eligible; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="flash warn"><?php echo e($p->address); ?> has been suspended long enough to be deleted (since <?php echo e($p->delete_after->format('Y-m-d')); ?>). <a href="<?php echo e(route('mailboxes.index', ['q' => $p->address])); ?>">Review</a></div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<div class="grid">
<?php $__empty_1 = true; $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <?php ($d = $r['domain']); ?>
    <div class="card">
        <strong><a href="<?php echo e(route('mailboxes.index', ['domain_id' => $d->id])); ?>"><?php echo e($d->name); ?></a></strong>
        <div class="muted small"><?php echo e($d->purpose); ?></div>
        <p><span class="stat"><?php echo e($r['mailboxes']); ?></span> mailboxes · <span class="stat"><?php echo e($r['forwarders']); ?></span> forwarders</p>
        <div>
            Near quota: <span class="badge <?php echo e($r['near_quota'] ? 'warn' : 'ok'); ?>"><?php echo e($r['near_quota']); ?></span>
            Health:
            <?php if($r['health']): ?><span class="badge <?php echo e($r['health']['worst']); ?>"><?php echo e($r['health']['worst']); ?></span><?php else: ?><span class="badge">not checked</span><?php endif; ?>
        </div>
        <div class="muted small">Last sync:
            <?php if($r['last_sync']): ?><?php echo e($r['last_sync']->started_at->diffForHumans()); ?><?php if($r['last_sync']->errors): ?> <span class="badge bad">errors</span><?php endif; ?> <?php else: ?> never <?php endif; ?>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="card">No domains yet. <?php if(auth()->user()->isSuperAdmin()): ?><a href="<?php echo e(route('admin.domains.create')); ?>">Add one</a>.<?php else: ?> Ask a super admin to give you access.<?php endif; ?></div>
<?php endif; ?>
</div>

<h2>Mailboxes at <?php echo e($warnPct); ?>% of quota or more</h2>
<table>
    <tr><th>Address</th><th>Used</th><th>Quota</th><th></th></tr>
    <?php $__empty_1 = true; $__currentLoopData = $nearQuotaBoxes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr><td><a href="<?php echo e(route('mailboxes.show', $m)); ?>"><?php echo e($m->address); ?></a></td><td><?php echo e($m->used_mb); ?> MB</td><td><?php echo e($m->quota_mb); ?> MB</td><td><?php echo e($m->usagePercent()); ?>%</td></tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr><td colspan="4" class="muted">None.</td></tr>
    <?php endif; ?>
</table>
<p class="muted small"><?php echo e($queued); ?> job(s) waiting in the queue.</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Xamp\htdocs\Cpanel-Email_system\mailpanel\resources\views/dashboard.blade.php ENDPATH**/ ?>