<?php $__env->startSection('title', 'Import domains'); ?>
<?php $__env->startSection('content'); ?>
<h1>Import domains from cPanel</h1>
<p class="muted">Domains and subdomains that cPanel can host mail for and the panel does not manage yet. Importing only adds them here; nothing changes in cPanel. Mailboxes, forwarders and the catch-all are loaded by a sync right after.</p>

<?php if(empty($available)): ?>
    <div class="card">Every mail domain in cPanel is already in the panel.</div>
<?php else: ?>
<form method="post" action="<?php echo e(route('admin.domains.import.store')); ?>">
    <?php echo csrf_field(); ?>
    <div class="card">
        <?php $__currentLoopData = $available; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <label style="display:block;margin:.3rem 0"><input type="checkbox" name="domains[]" value="<?php echo e($name); ?>" checked> <?php echo e($name); ?></label>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <p><button type="submit">Import selected</button> <a class="btn sec" href="<?php echo e(route('admin.domains.index')); ?>">Cancel</a></p>
</form>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Xamp\htdocs\Cpanel-Email_system\mailpanel\resources\views/admin/domains/import.blade.php ENDPATH**/ ?>