<?php $__env->startSection('title', 'Sign in'); ?>
<?php $__env->startSection('content'); ?>
<div class="card login">
    <h1><?php echo e(config('app.name')); ?></h1>
    <p class="muted">Sign in with your approved Google account. Ask a super admin to add you if you cannot get in.</p>
    <p><a class="btn" href="<?php echo e(route('auth.google')); ?>">Sign in with Google</a></p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Xamp\htdocs\Cpanel-Email_system\mailpanel\resources\views/auth/login.blade.php ENDPATH**/ ?>