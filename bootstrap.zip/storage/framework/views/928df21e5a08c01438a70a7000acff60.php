<?php $__env->startSection('title', 'Audit log'); ?>
<?php $__env->startSection('content'); ?>
<h1>Audit log</h1>
<form method="get" class="filters">
    <?php if($users->isNotEmpty()): ?>
        <div><label>User</label><select name="user_id"><option value="">Anyone</option>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($u->id); ?>" <?php if(request('user_id') == $u->id): echo 'selected'; endif; ?>><?php echo e($u->email); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
    <?php endif; ?>
    <div><label>Domain</label><select name="domain_id"><option value="">All</option>
        <?php $__currentLoopData = $domains; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($d->id); ?>" <?php if(request('domain_id') == $d->id): echo 'selected'; endif; ?>><?php echo e($d->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
    <div><label>Action starts with</label><input type="text" name="action" value="<?php echo e(request('action')); ?>" placeholder="mailbox."></div>
    <div><label>Target contains</label><input type="text" name="q" value="<?php echo e(request('q')); ?>"></div>
    <div><label>Result</label><select name="result"><option value="">Any</option>
        <?php $__currentLoopData = ['success', 'failure', 'denied']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option <?php if(request('result') === $r): echo 'selected'; endif; ?>><?php echo e($r); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
    <div><label>From</label><input type="date" name="from" value="<?php echo e(request('from')); ?>"></div>
    <div><label>To</label><input type="date" name="to" value="<?php echo e(request('to')); ?>"></div>
    <button type="submit">Filter</button>
    <a class="btn sec" href="<?php echo e(route('audit.export', request()->query())); ?>">Export CSV</a>
</form>

<table>
    <tr><th>Time</th><th>User</th><th>Action</th><th>Target</th><th>Domain</th><th>Result</th><th>IP</th></tr>
    <?php $__empty_1 = true; $__currentLoopData = $entries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr title="<?php echo e(json_encode($e->details)); ?>">
            <td class="small"><?php echo e($e->created_at->format('Y-m-d H:i:s')); ?></td>
            <td><?php echo e($e->user_email ?? $e->user?->email ?? 'system'); ?></td>
            <td><?php echo e($e->action); ?></td><td class="small"><?php echo e($e->target); ?></td><td><?php echo e($e->domain?->name); ?></td>
            <td><span class="badge <?php echo e($e->result === 'success' ? 'ok' : 'bad'); ?>"><?php echo e($e->result); ?></span></td>
            <td class="small muted"><?php echo e($e->ip); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="7" class="muted">No entries.</td></tr><?php endif; ?>
</table>
<div class="pager"><?php echo e($entries->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Xamp\htdocs\Cpanel-Email_system\mailpanel\resources\views/audit/index.blade.php ENDPATH**/ ?>