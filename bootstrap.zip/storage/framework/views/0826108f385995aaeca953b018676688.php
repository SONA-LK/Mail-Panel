<?php $__env->startSection('title', 'Settings'); ?>
<?php $__env->startSection('content'); ?>
<h1>Settings</h1>

<div class="card">
    <strong>cPanel connection</strong>
    <?php if($configured): ?>
        <p>Host <code><?php echo e($host); ?></code> · cPanel user <code><?php echo e($cpanelUser); ?></code> · certificate check <?php echo e($verifySsl ? 'on' : 'OFF'); ?></p>
        <?php if (! ($verifySsl)): ?><div class="flash warn">Certificate verification is off. Turn it on (CPANEL_VERIFY_SSL=true) outside of testing.</div><?php endif; ?>
        <p class="muted small">The API token lives in the server's .env file only and is never shown here. To rotate it, create a new token in cPanel, edit .env, run <code>php artisan config:cache</code>, then revoke the old token.</p>
        <form method="post" action="<?php echo e(route('admin.settings.test')); ?>"><?php echo csrf_field(); ?><button type="submit">Test connection</button></form>
    <?php else: ?>
        <div class="flash err">cPanel is not configured. Set CPANEL_HOST, CPANEL_USER and CPANEL_TOKEN in .env.</div>
    <?php endif; ?>
</div>

<div class="card">
    <strong>Sync with cPanel</strong>
    <p class="muted small">Runs automatically every night. A manual sync is queued and starts within a minute.</p>
    <form method="post" action="<?php echo e(route('admin.settings.sync-all')); ?>" class="inline"><?php echo csrf_field(); ?><button type="submit">Sync all domains</button></form>
    <?php $__currentLoopData = $domains; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <form method="post" action="<?php echo e(route('admin.settings.sync', $d)); ?>" class="inline"><?php echo csrf_field(); ?><button class="sec sm" type="submit"><?php echo e($d->name); ?></button></form>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<h2>Recent sync runs</h2>
<table>
    <tr><th>Started</th><th>Domain</th><th>Trigger</th><th>Added</th><th>Changed</th><th>Removed</th><th>Errors</th></tr>
    <?php $__empty_1 = true; $__currentLoopData = $runs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr><td class="small"><?php echo e($r->started_at->format('Y-m-d H:i')); ?></td><td><?php echo e($r->domain?->name); ?></td><td><?php echo e($r->trigger); ?></td>
            <td><?php echo e($r->added); ?></td><td><?php echo e($r->changed); ?></td><td><?php echo e($r->removed); ?></td><td class="small"><?php echo e($r->errors); ?></td></tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="7" class="muted">No runs yet.</td></tr><?php endif; ?>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Xamp\htdocs\Cpanel-Email_system\mailpanel\resources\views/admin/settings.blade.php ENDPATH**/ ?>