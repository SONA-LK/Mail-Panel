@extends('install.layout')
@section('title', 'Installed')
@section('content')
<div class="card">
    <h2>The panel is installed</h2>
    @foreach($r['warnings'] as $w)<div class="flash warn">{{ $w }}</div>@endforeach
    <p><strong>{{ $r['admin'] }}</strong> is the first super admin. {{ $r['imported'] }} domain(s) were added.</p>

    <h3>Two things left to do</h3>
    <ol>
        <li>
            <strong>Add the cron job</strong> (cPanel, Cron Jobs, once per minute). It runs the background queue, the nightly sync, health checks and the first sync of your domains:
            <pre>{{ $r['cron'] }}</pre>
            <span class="hint">If <code>php</code> is not found, use the full path your host shows under Cron Jobs, for example <code>/usr/local/bin/php</code>.</span>
        </li>
        <li>
            <strong>Check the Google redirect URI</strong> is registered exactly as <code>{{ $redirectUri }}</code>, then sign in:
            <p><a class="btn" href="{{ $r['login_url'] }}">Sign in with Google</a></p>
        </li>
    </ol>
    <p class="muted small">The setup wizard is now switched off. To run it again, delete <code>storage/app/installed.lock</code> and <code>.env</code>. Welcome emails to new mailboxes stay off until you set the <code>MAIL_*</code> values in <code>.env</code>.</p>
</div>
@endsection
