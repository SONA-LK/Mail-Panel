@extends('layouts.app')
@section('title', 'Settings')
@section('content')
<h1>Settings</h1>

<div class="card">
    <strong>cPanel connection</strong>
    @if($configured)
        <p>Host <code>{{ $host }}</code> · cPanel user <code>{{ $cpanelUser }}</code> · certificate check {{ $verifySsl ? 'on' : 'OFF' }}</p>
        @unless($verifySsl)<div class="flash warn">Certificate verification is off. Turn it on (CPANEL_VERIFY_SSL=true) outside of testing.</div>@endunless
        <p class="muted small">The API token lives in the server's .env file only and is never shown here. To rotate it, create a new token in cPanel, edit .env, run <code>php artisan config:cache</code>, then revoke the old token.</p>
        <form method="post" action="{{ route('admin.settings.test') }}">@csrf<button type="submit">Test connection</button></form>
    @else
        <div class="flash err">cPanel is not configured. Set CPANEL_HOST, CPANEL_USER and CPANEL_TOKEN in .env.</div>
    @endif
</div>

<div class="card">
    <strong>Sync with cPanel</strong>
    <p class="muted small">Runs automatically every night. A manual sync is queued and starts within a minute.</p>
    <form method="post" action="{{ route('admin.settings.sync-all') }}" class="inline">@csrf<button type="submit">Sync all domains</button></form>
    @foreach($domains as $d)
        <form method="post" action="{{ route('admin.settings.sync', $d) }}" class="inline">@csrf<button class="sec sm" type="submit">{{ $d->name }}</button></form>
    @endforeach
</div>

<h2>Recent sync runs</h2>
<table>
    <tr><th>Started</th><th>Domain</th><th>Trigger</th><th>Added</th><th>Changed</th><th>Removed</th><th>Errors</th></tr>
    @forelse($runs as $r)
        <tr><td class="small">{{ $r->started_at->format('Y-m-d H:i') }}</td><td>{{ $r->domain?->name }}</td><td>{{ $r->trigger }}</td>
            <td>{{ $r->added }}</td><td>{{ $r->changed }}</td><td>{{ $r->removed }}</td><td class="small">{{ $r->errors }}</td></tr>
    @empty<tr><td colspan="7" class="muted">No runs yet.</td></tr>@endforelse
</table>
@endsection
